package com.example.tictactoe

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.google.android.material.appbar.MaterialToolbar
import android.view.View
import androidx.core.view.isVisible
import com.google.android.material.snackbar.Snackbar
import java.util.*

class GameActivity : AppCompatActivity() {

    var flag = 0;
    var currentPlayer = "X";
    var AIIsPlaying = false;

    lateinit var topAppBar:MaterialToolbar
    lateinit var createNexGameButton: Button
    lateinit var settingsButton: Button

    val playerSide = mutableMapOf<String, String>()
    var gameResult  = mutableMapOf(
        "X" to 0,
        "O" to 0,
        "Tie" to 0
    )

    val rows = 3 // specify number of rows
    val cols = 4 // specify number of columns
    var map = Array(rows) {
        arrayOfNulls<Button>(cols)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        //Set up environment
        Init()
        AIIsPlaying = intent.getBooleanExtra("IS_AI_PLAYING", false)
        if(AIIsPlaying  == true){
            if(playerSide["X"] == "AI"){
                printMessage("Hello, ${playerSide["O"]}!")
                bestMove()
            }else {
                printMessage("Hello, ${playerSide["X"]}!")
            }
        } else{
            val view: View = findViewById(android.R.id.content)
            printMessage("Hello, ${playerSide["X"]}!\nHello, ${playerSide["O"]}!")
        }
    }

    fun Init(){
        setBoard()
        setResultToZero()
        displayResult()
        displayPlayers()
        setUpTopBar()

        //Settings Button clicked
        settingsButton = findViewById(R.id.settingsButton)
        settingsButton.setOnClickListener{
            val intent = Intent(GameActivity@this, SettingsActivity::class.java)
            startActivity(intent)
        }

        //New Game Button clicked
        createNexGameButton = findViewById(R.id.playAgainButton)
        createNexGameButton.setOnClickListener {
            callActivitySettings()
        }
    }

    fun displayPlayers(){
        val textViewPlayer1= findViewById<TextView>(R.id.textViewPlayer1)
        val textViewPlayer2= findViewById<TextView>(R.id.textViewPlayer2)

        playerSide["X"] = intent.getStringExtra("FIRST_PLAYER_NAME")?.toString() ?: ""
        playerSide["O"] = intent.getStringExtra("SECOND_PLAYER_NAME")?.toString() ?: ""

        textViewPlayer1.setText("Player(X): ${playerSide["X"]}")
        textViewPlayer2.setText("Player(O): ${playerSide["O"]}")
    }

    fun setUpTopBar(){
        topAppBar = findViewById(R.id.topAppBar)
        createNexGameButton = findViewById(R.id.settingsButton)

        topAppBar.setNavigationOnClickListener{
            Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show()
        }

        topAppBar.setOnMenuItemClickListener{menuItem ->
            when(menuItem.itemId){
                R.id.settings -> {
                    Toast.makeText(this, "Settings clicked", Toast.LENGTH_SHORT).show()
                    true;
                }

                else -> {
                    false
                }
            }
        }
    }

    fun setBoard(){
        map[0][0] = findViewById(R.id.btn1)
        map[0][1] = findViewById(R.id.btn2)
        map[0][2] = findViewById(R.id.btn3)
        map[1][0] = findViewById(R.id.btn4)
        map[1][1] = findViewById(R.id.btn5)
        map[1][2] = findViewById(R.id.btn6)
        map[2][0] = findViewById(R.id.btn7)
        map[2][1] = findViewById(R.id.btn8)
        map[2][2] = findViewById(R.id.btn9)
    }

    fun clearBoard(){
        clearButtons()
        currentPlayer = "X"
    }

    fun clearButtons(){
        val layout = findViewById<GridLayout>(R.id.boardLayout)

        for (i in 0 until layout.childCount) {
            val view = layout.getChildAt(i)
            if (view is Button) {
                view.text = ""
                view.isClickable = true
                view.isEnabled = true
            }
        }
    }

    fun makeBoardUnclickable(){
        val layout = findViewById<GridLayout>(R.id.boardLayout)

        for (i in 0 until layout.childCount) {
            val view = layout.getChildAt(i)
            if (view is Button) {
                view.isClickable= false
            }
        }
    }

    fun disableBoard(){
        val layout = findViewById<GridLayout>(R.id.boardLayout)

        for (i in 0 until layout.childCount) {
            val view = layout.getChildAt(i)
            if (view is Button) {
                view.isEnabled= false
            }
        }
    }

    fun disableButtons(buttonArray: Array<Button>){
        for (button in buttonArray) {
            button.isEnabled = false
        }
    }

    fun checkAllButtonsPressed(): Int{
        val layout = findViewById<GridLayout>(R.id.boardLayout)
        var count = 0
        for (i in 0 until layout.childCount) {
            val view = layout.getChildAt(i)
            if (view is Button) {
                if(view.text.toString() != "")
                {
                    count ++
                }
            }
        }
        return count
    }


    fun printMessage(message: String){
        val layout: LinearLayout = findViewById(R.id.custom_snackbar_layout)
        val textField: TextView = findViewById(R.id.snackbar_text)
        textField.setText(message)
        layout.isVisible = true

        val timer = Timer()
        timer.schedule(object : TimerTask() {
            override fun run() {
                runOnUiThread {
                    // This code will run on the main (UI) thread
                    layout.isVisible = false
                }
            }
        }, 2000)
    }

    fun setResultToZero(){
        gameResult["X"] = 0
        gameResult["O"] = 0
        gameResult["Tie"] = 0
    }

    fun displayResult(){
        val resultXLabel : TextView = findViewById(R.id.resultXLabel);
        val resultOLabel : TextView = findViewById(R.id.resultOLabel);
        val resultTieLabel : TextView = findViewById(R.id.resultTieLabel);

        resultXLabel.setText("X: ${gameResult["X"]}")
        resultOLabel.setText("O: ${gameResult["O"]}")
        resultTieLabel.setText("Tie: ${gameResult["Tie"]}")
    }

    fun gameEnded(){
        val buttonArray = checkIfGameEnded()
        if(buttonArray.isNotEmpty()){
            if(buttonArray.size == 1){
                disableBoard()
                printMessage("IT IS TIE")
                gameResult["Tie"] = gameResult["Tie"]?.plus(1) ?: 1
            }else{
                disableButtons(buttonArray)
                val winnerPlayerName = playerSide[buttonArray[0].text.toString()]
                printMessage("$winnerPlayerName has won!")
                gameResult["${buttonArray[0].getText()}"] = gameResult["${buttonArray[0].getText()}"]?.plus(1) ?: 1
            }
            makeBoardUnclickable()
        }
        switchPlayer()
        displayResult()
    }

    //This method will be called when button is clicked
    fun onClick(view: android.view.View){
        when(view.id){
            R.id.btn1 -> {
                val button : Button = findViewById(R.id.btn1);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn2 -> {
                val button : Button = findViewById(R.id.btn2);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn3 -> {
                val button : Button = findViewById(R.id.btn3);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn4 -> {
                val button : Button = findViewById(R.id.btn4);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn5 -> {
                val button : Button = findViewById(R.id.btn5);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn6 -> {
                val button : Button = findViewById(R.id.btn6);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn7 -> {
                val button : Button = findViewById(R.id.btn7);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn8 -> {
                val button : Button = findViewById(R.id.btn8);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }
            R.id.btn9 -> {
                val button : Button = findViewById(R.id.btn9);
                button.setText(currentPlayer)
                button.isClickable = false
                gameEnded()
                if(AIIsPlaying && checkIfGameEnded().isEmpty()){
                    bestMove()
                }
                true;
            }

            else -> {
                false
            }
        }

    }

    fun switchPlayer(){
        currentPlayer = if (currentPlayer == "X") "O" else "X"
    }

    fun compareButtonStrings(button1: Button, button2: Button): Boolean {
        val string1 = button1.text.toString()
        val string2 = button2.text.toString()

        if(string1 == string2 && string1 != null && string1 != ""){
            return true
        }
        return false
    }

    fun checkIfGameEnded(): Array<Button>{

        if(compareButtonStrings(map[0][0]!!,map[0][1]!!) && compareButtonStrings(map[0][0]!!,map[0][2]!!)){
            return arrayOf(map[0][0]!!, map[0][1]!!, map[0][2]!!)
        }else if(compareButtonStrings(map[1][0]!!,map[1][1]!!) && compareButtonStrings(map[1][0]!!,map[1][2]!!)){
            return arrayOf(map[1][0]!!, map[1][1]!!, map[1][2]!!)
        }else if(compareButtonStrings(map[2][0]!!,map[2][1]!!) && compareButtonStrings(map[2][0]!!,map[2][2]!!)){
            return arrayOf(map[2][0]!!, map[2][1]!!, map[2][2]!!)
        }else if(compareButtonStrings(map[0][0]!!,map[1][0]!!) && compareButtonStrings(map[0][0]!!,map[2][0]!!)){
            return arrayOf(map[0][0]!!, map[1][0]!!, map[2][0]!!)
        }else if(compareButtonStrings(map[0][1]!!,map[1][1]!!) && compareButtonStrings(map[0][1]!!,map[2][1]!!)){
            return arrayOf(map[0][1]!!, map[1][1]!!, map[2][1]!!)
        }else if(compareButtonStrings(map[0][2]!!,map[1][2]!!) && compareButtonStrings(map[0][2]!!,map[2][2]!!)){
            return arrayOf(map[0][2]!!, map[1][2]!!, map[2][2]!!)
        }else if(compareButtonStrings(map[0][0]!!,map[1][1]!!) && compareButtonStrings(map[0][0]!!,map[2][2]!!)){
            return arrayOf(map[0][0]!!, map[1][1]!!, map[2][2]!!)
        }else if(compareButtonStrings(map[0][2]!!,map[1][1]!!) && compareButtonStrings(map[0][2]!!,map[2][0]!!)){
            return arrayOf(map[0][2]!!, map[1][1]!!, map[2][0]!!)
        }else if (checkAllButtonsPressed() == 9){
            return arrayOf(map[0][2]!!)
        }

        return arrayOf<Button>()
    }

    fun minimax(depth: Int, isMaximizing :Boolean): Int{
        var bestScore = 0
        val winner = checkIfGameEnded()
        if(depth == 0){
            return 0
        }
        if(winner.size != 1 && winner.isNotEmpty()){
            val playerWon = winner[0].text.toString()
            if(playerWon == "X"){
               return depth*100000
            }else if(playerWon == "O"){
                return depth*(-100000)
            }
        }else if(winner.size == 1){
            return 0
        }

        if(isMaximizing){
            bestScore = -100000
        }else{
            bestScore = 100000
        }

        for (i in 0..2) {
            for (j in 0..2) {
                if(isMaximizing){
                    if(map[i][j]?.text.toString() == ""){
                        map[i][j]?.text = "X";
                        val score =  minimax(depth-1 ,false)
                        map[i][j]?.text = "";
                        if(score >= bestScore){
                            bestScore = score
                        }
                    }
                }else{
                    if(map[i][j]?.text.toString() == ""){
                        map[i][j]?.text = "O";
                        val score =  minimax(depth-1 ,true)
                        map[i][j]?.text = "";
                        if(score <= bestScore){
                            bestScore = score
                        }
                    }
                }
            }
        }
        return bestScore
    }

    fun bestMove(){
        var bestScore = 0
        var depth = 9
        if(currentPlayer == "X"){
            bestScore = -10000000;
        }else{
            bestScore = 10000000;
        }

        val move = arrayOfNulls<Int>(2)
        for (i in 0..2) {
            for (j in 0..2) {
                if(currentPlayer == "X"){
                    if(map[i][j]?.text.toString() == ""){
                        map[i][j]?.text = currentPlayer;
                        val score =  minimax(depth-1 ,false)
                        map[i][j]?.text = "";
                        if(score >= bestScore){
                            bestScore = score
                            move[0] = i
                            move[1] = j
                        }
                    }
                }else {
                    if (map[i][j]?.text.toString() == "") {
                        map[i][j]?.text = currentPlayer;
                        val score = minimax(depth - 1, true)
                        map[i][j]?.text = "";
                        if (score <= bestScore) {
                            bestScore = score
                            move[0] = i
                            move[1] = j
                        }
                    }
                }
            }
        }

        if(move[0] != null || move[1] != null){
            map[move[0]!!][move[1]!!]?.text = currentPlayer
            map[move[0]!!][move[1]!!]?.isClickable = false
        }


        gameEnded()
    }

    fun callActivitySettings(){
        clearBoard()
        if(AIIsPlaying  == true) {
            if (playerSide["X"] == "AI") {
                bestMove()
            }
        }
    }


}