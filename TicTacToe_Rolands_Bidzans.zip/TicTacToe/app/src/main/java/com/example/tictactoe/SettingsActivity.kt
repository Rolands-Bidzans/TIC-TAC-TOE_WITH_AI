package com.example.tictactoe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*


class SettingsActivity : AppCompatActivity() {

    lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        nextButton = findViewById(R.id.buttonNext)

        nextButton.setOnClickListener{
            callActivity()
        }

        //Choose game mode DropDown
        val items = listOf("PvC","PvP")
        val autoComplete : AutoCompleteTextView = findViewById(R.id.auto_complete)

        val adapter = ArrayAdapter(this, R.layout.list_item, items)

        autoComplete.setAdapter(adapter)

        autoComplete.onItemClickListener = AdapterView.OnItemClickListener{
            adapterView, view, i, l->

            val itemSelected = adapterView.getItemAtPosition(i)
            Toast.makeText(this,"Item: $itemSelected", Toast.LENGTH_SHORT).show()

            var playerTwoName: EditText = findViewById(R.id.personTwoName)

            if(itemSelected == "PvP"){
                playerTwoName.visibility = View.VISIBLE
            }else{
                playerTwoName.visibility = View.GONE
            }

        }

        //Choose game mode DropDown

    }

    private fun callActivity(){
        val intent = Intent(this,SettingsActivity2::class.java).also{
            val playerOneName: EditText = findViewById(R.id.personOneName)
            val playerTwoName: EditText = findViewById(R.id.personTwoName)
            val autoComplete : AutoCompleteTextView = findViewById(R.id.auto_complete)

            var firstPlayerName = playerOneName.text.toString()
            var secondPlayerName = playerTwoName.text.toString()
            if(autoComplete.text.toString() == "PvC"){
                secondPlayerName = "AI"
                if(firstPlayerName == "AI"){
                    firstPlayerName = "AI2"
                }
                it.putExtra("IS_AI_PLAYING", true)
            }else{
                it.putExtra("IS_AI_PLAYING", false)
                if(firstPlayerName == secondPlayerName){
                    secondPlayerName = "${secondPlayerName}2"
                }
            }


            println(secondPlayerName)
            it.putExtra("FIRST_PLAYER_NAME", firstPlayerName)
            it.putExtra("SECOND_PLAYER_NAME", secondPlayerName)
            startActivity(it)
        }
    }
}