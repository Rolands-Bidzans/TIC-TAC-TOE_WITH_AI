package com.example.tictactoe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class SettingsActivity2 : AppCompatActivity() {

    lateinit var startGameButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings2)

        val firstPlayerName = intent.getStringExtra("FIRST_PLAYER_NAME")
        val secondPlayerName = intent.getStringExtra("SECOND_PLAYER_NAME")

        val items = listOf(firstPlayerName,secondPlayerName)
        val playerNameWhoStarts : AutoCompleteTextView = findViewById(R.id.playerDropDown)
        playerNameWhoStarts.setText(firstPlayerName)
        val adapter = ArrayAdapter(this, R.layout.list_item, items)
        playerNameWhoStarts.setAdapter(adapter)

        //Choose game mode DropDown


        playerNameWhoStarts.onItemClickListener = AdapterView.OnItemClickListener{
                adapterView, view, i, l->

            val itemSelected = adapterView.getItemAtPosition(i)
            Toast.makeText(this,"Item: $itemSelected", Toast.LENGTH_SHORT).show()

        }

        //Button Clicked
        startGameButton = findViewById(R.id.buttonStart)

        startGameButton.setOnClickListener{
            callActivity()
        }

    }

    private fun callActivity(){
        val intent = Intent(this,GameActivity::class.java).also{
            val playerNameWhoStarts : AutoCompleteTextView = findViewById(R.id.playerDropDown)

            var firstPlayerName = intent.getStringExtra("FIRST_PLAYER_NAME")
            var secondPlayerName = intent.getStringExtra("SECOND_PLAYER_NAME")
            var isAIPlaying = intent.getBooleanExtra("IS_AI_PLAYING", false)
            if(firstPlayerName != playerNameWhoStarts.text.toString())
            {
                val template = firstPlayerName
                firstPlayerName = secondPlayerName
                secondPlayerName =  template
            }

            it.putExtra("FIRST_PLAYER_NAME", firstPlayerName)
            it.putExtra("SECOND_PLAYER_NAME", secondPlayerName)
            it.putExtra("IS_AI_PLAYING", isAIPlaying )
            startActivity(it)
        }
    }
}